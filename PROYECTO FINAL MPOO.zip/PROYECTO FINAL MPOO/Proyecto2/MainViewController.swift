//
//  MainViewController.swift
//  Proyecto2
//
//  Created by:
//  - Salazar Olivares Ricardo
//  - Yonatan Martín Galicia Serrano
//  on 14/11/24.
//

import UIKit

class MainViewController: UIViewController {
    
    @IBAction func addToCartAction(_ sender: Any) {
        if productDetailName.text != "Nombre del producto" {
            addProductToCart(product: ProductInfo(image: productDetailImage.image!, name: productDetailName.text!))
            
            let tabBar = self.tabBarController!.tabBar
            let downloadItem = tabBar.items![1]
            downloadItem.badgeColor = UIColor.red
            downloadItem.badgeValue = "\(productsInCart.count)"
            
            let vc = storyboard?.instantiateViewController(withIdentifier: "secondaryViewController") as! SecondaryViewController
            vc.productsInCart = productsInCart
            present(vc, animated: false)
        }
    }
    @IBOutlet weak var productDetailImage: UIImageView!
    @IBOutlet weak var productDetailName: UILabel!
    
    var productsInfo:[ProductInfo] = [
        ProductInfo(imageName: "item1", name: "Taladro"),
        ProductInfo(imageName: "item2", name: "Sierra de mano"),
        ProductInfo(imageName: "item3", name: "Caja de Herramientas"),
        ProductInfo(imageName: "item4", name: "Sierra de mesa"),
        ProductInfo(imageName: "item5", name: "Mancuernas")]
    
    var productsInCart:[ProductInfo] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func setProductDetailInfo(productImage:UIImage, productName:String) {
        
        productDetailImage.image = productImage
        productDetailName.text = productName
    }
    func addProductToCart(product:ProductInfo) {
        productsInCart.append(product)
    }
}

extension MainViewController:UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return productsInfo.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! MyCollectionViewCell
        let product = productsInfo[indexPath.row]
        
        cell.productImageCell.image = product.productImage
        cell.productNameCell.text = product.productName
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let product = productsInfo[indexPath.row]
        self.setProductDetailInfo(productImage: product.productImage, productName: product.productName)
    }
}
